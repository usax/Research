module.exports = function(config) {
  config.set({
    basePath: '',
    autoWatch: true,
    frameworks: ['jasmine'],
    files: [
      'sqrt.js',
      'test/spec/*.js'
    ],
    browsers: ['PhantomJS'],

    reporters: ['progress', 'coverage'],
		  coverageReporter: {
    // specify a common output directory
    dir: 'build/reports/coverage',
    reporters: [
      { type: 'lcov', subdir: 'report-lcov' },
      { type: 'lcovonly', subdir: '.', file: 'report-lcovonly.txt' }
    ]
  },
    preprocessors: { '*.js': ['coverage'] },

    singleRun: true
  });
};
