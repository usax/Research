'use strict';
require('./')();
