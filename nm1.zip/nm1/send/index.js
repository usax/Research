
module.exports = require('./lib/send');